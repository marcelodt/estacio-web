import { useEffect } from 'react';
import { createPortal } from 'react-dom';
import { twMerge } from 'tailwind-merge';

export const Sidebar = ({ isOpen, onClose }) => {
  useEffect(() => {
    document.body.style.overflow = (isOpen && 'hidden') || '';
  }, [isOpen]);

  return createPortal(
    <section
      className={twMerge(
        'fixed bottom-0 top-0 z-10 h-full w-72 right-0  shadow-lg bg-white transition-all duration-200 lg:bg-indigo-800',
        (isOpen && 'translate-x-0') || 'translate-x-full'
      )}
    >
      <header className="sticky top-0 border-b border-b-gray-200 bg-white">
        <div className="flex h-20 items-center justify-between px-8 lg:container lg:mx-auto">
          <button
            onClick={onClose}
            className="flex items-center rounded-md p-3"
          >
            Fechar
          </button>
        </div>
      </header>
      <div className="lg:container lg:mx-auto lg:px-0">dssdsd</div>
    </section>,
    document.body
  );
};
