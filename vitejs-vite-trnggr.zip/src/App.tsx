import { Header } from './header';
import { Sidebar } from './sidebar';

function App() {
  return (
    <div>
      <Header />
      <Sidebar isOpen />
    </div>
  );
}

export default App;
