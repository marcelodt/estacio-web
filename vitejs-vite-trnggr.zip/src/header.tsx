export const Header = () => {
  return <header className="bg-indigo-800 h-20 flex items-center px-4 justify-between">
    <h1 className="text-white">Titulo</h1>
    <button className="text-white">Abrir</button>
  </header>;
};
